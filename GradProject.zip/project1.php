<html xmlns="http://www.w3.org/1999/html">
<head>
    <title>Maggie's Page</title>
</head>
<body style="background-color: silver">
<?php
//paste the statements here
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "login");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

//if(!isset($_POST('submit')) { $run = true; }

// Attempt select query execution
$userinput= (isset($_POST['userid'])? $_POST['userid'] : '');
//$pass= (isset($_POST['password'])? $_POST['password'] : '');

$sql = "SELECT * FROM userlogin WHERE userid = '$userinput' LIMIT 100";
//echo $sql;

//$sql1 = "SELECT * FROM userlogin WHERE password = '$pass' LIMIT 20";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table>";
        echo "<tr>";
        //echo "<th>Login Successful</th>";
        echo "<th>userid</th>";
        echo "<th>password</th>";
        echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>" . $row['userid'] . "</td>";
            echo "<td>" . $row['password'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        // Close result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Unable to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>
<form method="post" action="">
    <br>
    <div style="width: 100%; text-align: center;">
        <h2>
            Maggie's login form
        </h2>
        <br>
        <br>
        enter userid: <input type="text" name="userid">
        <br>
        <br>
        <input type="submit"
               value="submit query">
        <br>
    </div>
</form>
</body>
</html>
